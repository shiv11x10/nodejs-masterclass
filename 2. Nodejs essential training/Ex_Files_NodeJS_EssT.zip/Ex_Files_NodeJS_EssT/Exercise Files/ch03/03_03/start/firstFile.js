let hello = "Hello World From NODE JS";

console.log(hello);
